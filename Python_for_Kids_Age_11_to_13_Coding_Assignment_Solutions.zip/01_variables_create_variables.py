fullname = 'David Crusoe'
age = 25
fav_city = 'Paris'
play_football = 'No'

print(fullname)
print(age)
print(fav_city)
print(play_football)
