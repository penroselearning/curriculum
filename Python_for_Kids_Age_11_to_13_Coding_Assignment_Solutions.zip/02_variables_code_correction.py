city = "New York"
zipcode = 10003

print(city)
print(zipcode)# Write your code here :-)
