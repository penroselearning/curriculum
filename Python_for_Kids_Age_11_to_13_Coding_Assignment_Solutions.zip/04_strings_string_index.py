name = input("Enter your name: ")

print(name.lower())
print(name.upper())
print(name.title())
