course = 'Python'

print(course[0].upper())
print(course[1].upper())
print(course[2].upper())
print(course[3].upper())
print(course[4].upper())
print(course[5].upper())
