full_name = "Sarah Robert"

firstname,lastname = full_name.split()

print(f"Firstname: {firstname}")
print(f"Lastname: {lastname}")
