name = "Mr. Brian Charles Lara"

title,firstname,middlename,lastname = name.split()

print(f"{lastname}, {firstname} {middlename}")
