name = input("Enter your name:\n").title().strip()
course = input(f"{name}, what course you are learning?\n").title().strip()
website = input("{name}, from which website are you learning {course} from?\n").upper().strip()

print(f'{name} is learning {course} from {website}')
