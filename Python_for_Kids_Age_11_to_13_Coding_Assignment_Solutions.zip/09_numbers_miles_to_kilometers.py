miles = int(input("Enter a value for Miles: "))

km = miles * 1.609

print(f'{miles} miles equals {km} kilometers')
