num = int(input("Enter a number of your choice: "))

square = num ** 2
cube = num ** 3

print(f"Square of {num} is {square} and its Cube is {cube}")
