protein = int(input("Enter Protiens in Grams: "))
carbs = int(input("Enter Carbs in Grams: "))
fat = int(input("Enter Fat in Grams: "))

calories = (protein * 4) + (carbs * 4) + (fat * 9)

print("Total Calories: ", calories)
