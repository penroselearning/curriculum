import random

shirts = ['brown full-sleeve shirt','white t-shirt','blue half-sleeve shirt']
trousers = ['shorts','harem pants','jeans','khaki pants']
shoes = ['sports shoe','formal shoe','slipper']

print(f'{random.choice(shirts)} with {random.choice(trousers)} and {random.choice(shoes)}')
