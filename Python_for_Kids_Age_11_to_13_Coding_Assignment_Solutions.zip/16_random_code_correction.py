import random
dice = random.randint(1,6)

print(f"The Dice roll returned {dice}")
