num = int(input("Enter a number of your choice: "))

if num < 1 or num > 12:
    print("Provide a number greater than 1 and less than 13")
    exit()

for x in range(1,13):
    print(f'{num} x {x} = {num*x}')
