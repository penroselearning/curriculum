import random

computer_score = 0
player_score = 0

for x in range(5):
    print()
    print("Round",x+1)
    computer = random.randint(1,5)
    player = int(input("Enter your Guess (1/2/3/4/5): "))

    if computer == player:
        print(f"Congrats, You Win Round {x+1}")
        player_score += 1
    else:
        print(f"Sorry!! You lost. The computer chose {computer}")
        computer_score += 1

print()
print("Player Score",player_score,"- Computer Score",computer_score)

if player_score > computer_score:
    print("You have won the Game")
else:
    print("You have lost!! Better luck next time")

