print("The Square of numbers")

for x in range(1,10):
    print(f"The Square of {x} is {x * x}")
