PASSWORD='12345@'

attempts=3
pin = input("Enter your Account Pin:\n")
attempts -= 1

while pin != PASSWORD:
  if attempts > 0:
      pin = input(f'''Sorry, the password is incorrect.You have {attempts} more attempt/s.
Please enter your Account Pin again:\n''')
      attempts -= 1
  else:
      print('Sorry, you have entered an incorrect password 3 times. Your account has been blocked :-(')
      exit()

print('-'*30)
print("Welcome to your Account.")
