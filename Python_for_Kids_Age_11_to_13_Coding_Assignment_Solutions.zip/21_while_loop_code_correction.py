number = 1

while number <= 10:
    print(number * number)
    number += 1
