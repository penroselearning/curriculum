dream_team = ['Stephen Curry', 'LeBron James', 'Michael Jordan', 'Kobe Bryant', 'James Harden']
x = 1

print("Basketball Dream Team:")
print('-' * 30)
for player in dream_team:
    print(f'{x}.{player}')
    x += 1

