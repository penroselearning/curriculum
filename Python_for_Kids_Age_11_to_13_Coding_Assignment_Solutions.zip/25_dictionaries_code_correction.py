country_city = {'UAE' : 'Dubai',
'India' : 'Mumbai',
'Norway' : 'Bergen',
'Australia' : 'Sydney',
'Spain' : 'Madrid'}

for country,city in country_city.items():
    print(country,city)
