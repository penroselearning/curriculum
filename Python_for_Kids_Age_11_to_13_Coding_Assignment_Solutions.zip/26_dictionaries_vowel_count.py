word = input("Enter a word of your choice: ")

vowels = 'aeiou'

vowel_count = {'a': 0,'e':0,'i':0,'o':0,'u':0}

for l in word:
    if l in vowels:
        vowel_count[l] += 1

print(vowel_count)
