
score = 0

def add_score(score):
    score = score + 1

score = add_score()

print(f'Current Score: {score}')

