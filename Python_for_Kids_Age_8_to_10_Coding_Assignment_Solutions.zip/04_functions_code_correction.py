country = 'New Zealand'
capital = 'Wellington'
print('The capital of', country,'is',capital)
