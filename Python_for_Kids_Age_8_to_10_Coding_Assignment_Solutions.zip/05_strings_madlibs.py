name = input("What is your name? ")
food = input("What is your favorite food? ")
city = input("Which city do you reside in? ")


funny_story = f'{name}, the mayor of {city} city, eats 10 portions of {food}'s each day to keep himself fit to lead the city'

print(funny_story)
