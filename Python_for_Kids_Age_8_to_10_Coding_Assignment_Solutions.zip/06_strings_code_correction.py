name = 'Sandra'
food = 'Pizza'

print(f'{name} loves {food}')
