total_candies = 72

students = 34
candies_distributed = students * 2

remaining_candies = total_candies - candies_distributed

print(f'The remaining candies are {remaining_candies}')
