total_cookies = 24
number_of_friends = 8

cookies_per_friend = total_cookies // number_of_friends

print(f'Each friend gets {cookies_per_friend} cookies')
