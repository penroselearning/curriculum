total_children = 6
tickets_per_child = 4
total_tickets = total_children * tickets_per_child

print("Total Tickets: ", total_tickets)
