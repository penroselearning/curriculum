num = int(input("Enter a number of your choice"))

print('Multiplication Table')
print(f'{num} x 1 = {num * 1}')
print(f'{num} x 2 = {num * 2}')
print(f'{num} x 3 = {num * 3}')
