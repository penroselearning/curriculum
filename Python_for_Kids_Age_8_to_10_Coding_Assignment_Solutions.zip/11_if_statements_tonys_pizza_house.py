margarita = 10
pepperoni = 15
barbeque = 17

print("Menu - Tony's Pizza House")
print("*" * 30)
print("Margarita: USD",margarita)
print("Pepperoni: USD",pepperoni)
print("Barbeque: USD",barbeque)
print()

order = input("Enter your Order: ").lower()

bill = 0

if order == 'margarita':
    bill = bill + margarita
elif order == 'pepperoni':
    bill = bill + pepperoni
elif order == 'barbeque':
    bill = bill + barbeque
else:
    print(f"Sorry! We do not sell {order}")
    exit()

print(f"Your Final bill is USD {bill}")
