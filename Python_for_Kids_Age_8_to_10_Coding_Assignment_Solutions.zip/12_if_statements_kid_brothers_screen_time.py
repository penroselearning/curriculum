selected_program = input('Which App are you using? gaming, math, science or reading: ')

if selected_program == 'gaming':
    print("Your tablet will be turned off after 15 minutes")
elif selected_program == 'math':
    print("Your tablet will be turned off after 20 minutes")
elif selected_program == 'science':
    print("Your tablet will be turned off after 20 minutes")
elif selected_program == 'reading':
    print("Your tablet will be turned off after 25 minutes")
else:
    print("Sorry, this App is not permitted for you. Your tablet will be turned off after 1 minute")
