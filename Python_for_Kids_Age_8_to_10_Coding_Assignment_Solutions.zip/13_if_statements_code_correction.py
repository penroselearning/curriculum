today = "Saturday"

if today == "Saturday" or today == "Friday":
    print("Weekend")
else:
    print("Weekday")
