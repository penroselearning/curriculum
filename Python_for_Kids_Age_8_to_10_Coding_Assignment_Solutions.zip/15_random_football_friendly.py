import random

football_teams = ['Belgium','Brazil','Argentina','England','Germany',
'Spain','France','Portugal']

print("Football Teams")
print(football_teams)
print()

for x in range(1,5):
    team1 = random.choice(football_teams)
    football_teams.remove(team1)

    team2 = random.choice(football_teams)
    football_teams.remove(team2)

    print(f'Match {x} - {team1} vs {team2}')
