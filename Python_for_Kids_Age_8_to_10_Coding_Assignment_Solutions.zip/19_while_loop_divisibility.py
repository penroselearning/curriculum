x = 1
n = 7

while x <= 50:
    if x % n == 0:
        print(f"{x} is Divisible by {n}")
    x += 1
