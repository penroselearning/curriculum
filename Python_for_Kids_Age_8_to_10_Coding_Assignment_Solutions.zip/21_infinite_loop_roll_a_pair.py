import random

tries = 0

while True:
    die1 = random.randint(1,6)
    die2 = random.randint(1,6)

    tries = tries + 1
