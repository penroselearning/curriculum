shopping_list = []

print("Add Items to the Shopping List")
for x in range(5):
    new = input("Enter Item: ")
    shopping_list.append(new)

print(shopping_list)
