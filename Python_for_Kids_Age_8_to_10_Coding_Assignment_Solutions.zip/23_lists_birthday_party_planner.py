party_planner = ['Prepare a Guest List',
'Order a Cake']

print("Party To-Do List")

while len(party_planner) < 6:
    todo = input(">: ")
    party_planner.append(todo)

print(party_planner)
