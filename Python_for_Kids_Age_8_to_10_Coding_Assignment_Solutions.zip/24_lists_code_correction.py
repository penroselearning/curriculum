import random

superheroes = ['Batman','Superman','Spiderman']

print(random.choice(superheroes))
