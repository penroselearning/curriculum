nums = [1,4,2,17,3,111,0,13,27,14,0,23,11,25,12,19]

even = []
odd = []

for num in nums:
    if num % 2 == 0:
        even.append(num)
    else:
        odd.append(num)

print()
print("There are {len(even)} Even Numbers")
print(even)

print()

print("There are {len(odd)} Odd Numbers")
print(odd)
