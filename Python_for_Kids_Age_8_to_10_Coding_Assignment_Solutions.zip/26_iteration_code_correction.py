
oceans = ['Arctic', 'Southern', 'Indian', 'Atlantic','Pacific']

for ocean in oceans:
    print(ocean)
