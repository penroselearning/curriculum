def table(n1,n2):
    for x in range(1,n2+1):
        print(f'{n1} x {x} = {n1*x}')


n1 = int(input("Enter the Multiplicand: "))
n2 = int(input("Enter the Max Multiplier: "))

table(n1,n2)
