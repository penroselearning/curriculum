import random

def roll_dice():
    return random.randint(1,6)

print(roll_dice())
