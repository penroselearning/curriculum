## --- VARIABLES IN R ----

# any character in quotations is a string
name <- "David"
no_of_bags <- "10" # string

# integer +ve and -ve without decimal nos.
age <- 35

# float (decimal nos.) +Ve and -ve
height = 150.2

address <- 'Dubai, UAE'

address

cat(name, "is", age, "years old and he lives in", address)

# 1stname <- "David" this is wrong

# first name <- "David" this is wrong no spaces in between var. names

first_name <- "John"

firstName <- "John"

first.name <- "John"

age <- 35

AGE <- 36

Age <- 37

# boolean <- TRUE and FALSE

is_raining <- FALSE

# FALSE <- "HELLO" cannot use Reserved words as variables.

age <- 20

## --- MATH IN R ----

# max() - returns the max value in a list of numbers

max_no <- max(16,2,43,76,12,5,12,98,2)
max_no

# min() - returns the min value in a list of nos.

min(16,2,43,76,12,5,12,98,2)

nos <- c(16,2,43,76,12,5,12,98,2)
max(nos)
min(nos)

# sqrt() - square root of a number

sqrt(25)

# abs() - returns the absolute value of a number

abs(-64.1)

# ceiling() - returns the highest possible value of a number

num1 <- 12.2223
ceiling(num1)
ceiling(65.1112)

# floor() - returns the lowest possible value.

num2 <- 12.6678
floor(num2)
floor(64.112)

# arithmetic operations

num1 <- 5
num2 <- 2

# sum of two numbers

final_sum <- num1 + num2
final_sum

# subtract
difference <- num1 - num2
difference

# multiply
product <- num1 * num2
product

# divide and find the quotient
quotient <- num1 / num2
quotient

# divide and find the remainder
remainder <- num1 %% num2
remainder

# exponential value of num1 raised to num2
exponent <- num1 ^ num2
exponent

random_sum <- 5 + 2
random_sum

nos <- c(68,59,12,5,31,24,76,12,54,33,88,12,87,59,34,56,98,23,5,76,38,9,43,36,39,25,1,32,64,77,22,30)

sort(nos, decreasing = FALSE)

max(68.55,59.11)

ceiling(max(68.55,59.11))

# use case: return the credit rating based on the credit score

credit_score <- 600

# credit_score more than 750 -> Excellent
# credit_score between 650 and 750 -> Good
# credit_score between 500 and 650 -> Fair
# credit_score below 500 -> Poor

credit_score <- 59

if(credit_score >= 750) {
  credit_rating <- "Excellent"
} else if (credit_score >= 650 && credit_score < 750) {
  credit_rating <- "Good"
} else if (credit_score >= 500 && credit_score < 650) {
  credit_rating <- "Fair"
} else if (credit_score < 500 && credit_score >= 0) {
  credit_rating <- "Poor"
} else {
  cat("Invalid Credit Score")
}

if (credit_score >= 0) {
  cat("The Credit Rating for",credit_score,"is",credit_rating)
}

name <- "John"


# == check the value/data of a variable
if (name == "David") {
  cat("Hi David!")
} else {
  cat("I don't know you!")
}

# != checks whether the value/data of the var. is same to which is compared with.
if (name != "David") {
  cat("I don't know you!")
} else (
  cat("Hi David")
)

name <- "John"
address <- "Dubai"

# || -> the OR operator check either one of condition is TRUE

#       FALSE                 TRUE

if (name == "David" || address == "Dubai") {
  cat("Hello Welcome To R")
}

is_sunny = FALSE

if(!is_sunny) {
  cat("It's a sunny day")
}

# 18, 4, 5, 6, 0, -14

# DRY - Dont Repeat Yourself


# for loops are loops that allow the program to do a set of task repeatedly based on the range provided.

#        123456789...
name <- "David Letterman"

cat(substr(name,1,1))
cat(substr(name,2,2))
cat(substr(name,3,3))

cat(nchar(name))

# we used nchar() function so that we can find the size of the name var. i.e. 15

# in the for loop, we created a range to start from 1 and go till the value of the name var.'s size -> 15

# itr -> 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15

for (itr in 1:nchar(name)) {
  cat(substr(name,itr,itr), "\n")
}


# a simple for loop that executes tasks 10 times

for (x in 1:10) {
  cat("Hello World. \n")
}

number <- 9

for (x in 1:10) {
  cat(number, "x", x, "=",  x*number, "\n")
}


names <- list("Josh", "David", "Joseph", "Yusuf", "Deacon")

# accessing items in a list using index no,
names[4]

#                           1             2     3       4
customer_data <- list("Deacon St.John", 2019, TRUE, "Dubai, UAE")

# loop through each item in a list
for(data in customer_data){
  print(data)  
}

# merge two lists

list1 <- list(1,2,3)
list2 <- list("Sun", "Mon", "Tues", "Wed")

# this will create a two dimensional list
merged_list <- list(list1, list2)
merged_list <- c(list1, list2)

merged_list


#[
#  [1,2,3],
#  ["Sun", "Mon","Tues"]
#]

customer_data_vector <- c("Deacon St.John", 2019, TRUE, "Dubai, UAE")

customer_data_vector
customer_data

# dataframes

sales_df <- data.frame(
  salesman = c("John", "David", "Carlos"),
  sales = c(100, 150, 120),
  profit = c(60, 30, 45)
)

sales_df
