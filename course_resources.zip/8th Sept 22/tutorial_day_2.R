library(tidyverse)
library(rpart)
library(rpart.plot)
library(caret)
library(caTools)
library(ROCR)

getwd()
setwd('C:/Users/smoot/OneDrive/Desktop/rTraining/8th Sept 22')

df = read_csv('bank_data_for_r.csv')

## DESCRIBE AND EXPLORE DATA

# no of columns in the dataframe

ncol(df)

# no of rows in the dataframe

nrow(df)

# print all the columns in the dataframe

str(df)

# summary of the dataframe

summary(df)

# accessing a specific column

df$Home_Ownership

# unique values in a column

unique(df$Home_Ownership)

# find a count of the unique values

table(df$Home_Ownership)


# TASK 1 Solution
employee_attrition_df=read_csv('https://raw.githubusercontent.com/acekhan1999/penroselearning/master/employee_attrition.csv')
ncol(employee_attrition_df)
nrow(employee_attrition_df)
summary(employee_attrition_df)
unique(employee_attrition_df$Department)
table(employee_attrition_df$Department)


str(df)

# the datatype of a column 
class(df$Purpose)

# unique values in Purpose Column
unique(df$Purpose)

# change Purpose Column to Categorical Class

df$Purpose <- as.factor(df$Purpose)

# SELECT AND FILTER DATA

new_df <- subset(df, df$Current_Loan_Amount >= 25000)

new_df

str(new_df)

#sort(unique(new_df$Current_Loan_Amount))
sort(unique(new_df$Annual_Income))

new_df <- subset(df, df$Current_Loan_Amount >= 25000, select = c("Customer_ID", "Defaulter", "Current_Loan_Amount", "Term", "Credit_Score", "Home_Ownership", "Purpose"))

# multiple conditions 
new_df <- subset(df, df$Current_Loan_Amount >= 25000 & df$Annual_Income >= 100000, select = c("Customer_ID", "Defaulter", "Current_Loan_Amount", "Term", "Annual_Income", "Credit_Score","Home_Ownership", "Purpose"))

# write a csv file for a dataframe
write_csv(new_df, 'bank_data_sample.csv')

# FIND AND FIX MISSING DATA (NULL VALUES)

# check for NULL values in the column
is.na(new_df$Purpose)


# change the NA values to "Others"

new_df$Purpose[is.na(new_df$Purpose)] <- "Others"


# change the Purpose column from factor to character

new_df$Purpose <- as.character(new_df$Purpose)

class(new_df$Purpose)

new_df$Purpose[is.na(new_df$Purpose)] <- "Others"

unique(new_df$Purpose)

new_df$Purpose <- as.factor(new_df$Purpose)

class(new_df$Purpose)
unique(new_df$Purpose)

# FIND AND FIX DUPLICATE VALUES

duplicated(new_df)

# this is unique values with count
table(duplicated(new_df))

# this is only the unique values
unique(duplicated(new_df))

str(employee_attrition_df)

# TASK 2 - SOLUTION
new_employee_attrition_df <- subset(employee_attrition_df,employee_attrition_df$Department == "Research & Development" & employee_attrition_df$HourlyRate >45,select = c("HourlyRate","PercentSalaryHike","JobSatisfaction","YearsSinceLastPromotion","YearsWithCurrManager", "Department"))

is.na(new_employee_attrition_df)

table((duplicated(new_employee_attrition_df)))

## DATA TRANSFORMATION

unique(new_df$Purpose)


employee_df <- data.frame (
  Employee_ID = c("EID-122", "EID-123", "EID-123", "EID-124"),
  Employee_name = c("Josh Matthew", "Eric Jerald", "Deacon St. John", "Joshua T."),
  Department = c("PR", "IT", "PR", "Sales")
)

# One-Hot Encoding for the Department Column

encoded_cols <- dummyVars("~ Department", data=employee_df)

new_employee_encoded_cols_df <- data.frame(predict(encoded_cols, newdata = employee_df))

new_employee_encoded_cols_df

employee_df <- merge(employee_df, new_employee_encoded_cols_df, by="row.names", all.x=TRUE)


employee_df = select(employee_df, -c("Department", "Row.names"))

employee_df

encoded_new_df_dummies <- dummyVars('~ Term + Home_Ownership + Purpose', data=new_df)
new_encoded_new_df_dummies <- data.frame(predict(encoded_new_df_dummies, newdata = new_df))

new_encoded_new_df_dummies

new_df <- merge(new_df, new_encoded_new_df_dummies, by="row.names", all.x = TRUE)

new_df

new_df <- select(new_df, -c("Term", "Home_Ownership", "Purpose"))

## DATA VISUALIZATION

table(df$Home_Ownership)




colors = c("red", "green", "blue")
png(file = 'barchart_stacked.png')

barplot(table(df$Home_Ownership), main="Home Ownership", xlab = "Ownership", ylab="count", col=colors)
# barplot(df$Home_Ownership, main="Home Ownership", xlab = "Ownership", ylab="count", col=colors)

legend("topleft", regions, fill=colors)

dev.off()

set.seed(789)
split = sample.split(new_df$Defaulter, SplitRatio = 0.7)
train = subset(new_df, split == TRUE)
test = subset(new_df, split == FALSE)


classifier <- glm(Defaulter ~ Credit_Score + TermLong.Term+ TermShort.Term+ Home_OwnershipHome.Mortgage+ Purpose.Business.Loan, family=binomial, data=train)

classifier <- step(classifier)

prob_pred <- predict(classifier, type="response", newdata = test)
y_pred <- ifelse(prob_pred > 0.5, 1, 0)

error <- mean(test$Defaulter != y_pred)

cat("Accuracy", round(1-error, 4))


table(test$Defaulter, y_pred > 0.5)


